# UUV pipeline detection and monitoring data

This folder contains the UUV side scan sonar data from the UUV ROS simulator. The data is split into 4 sessions, each with multiple "iterations" aka runs of the simulator. 

File naming guide: 
 * ..right or ..left.. or ..both.. indicates which side the UUV. Monitors and detectors operate over the "both" traces, using the at_one field as the primary binary variable.  
 * det1 is a stateless detector with fpr=fnr=0.1
 * mon1_d is a shorthand for the pipeline recovery (PR) monitor with deadline d over det1
 * mon11_d is a shorthand for the reliable following (RF) monitor with deadline d over det1
 * det2.x is a stateful detector with error parameter w=x
 * mon 2.x_d is a shorthand for the pipeline recovery (PR) monitor with deadline d over det2.x
 * mon 22.x_d is a shorthand for the pipeline recovery (PR) monitor with deadline d over det2.x
 * ..estrate.. contains the estimated rates for this folder and sub-folders.

Other:
 * src: scripts to generate and analyze the data. See various_tricks.bash for a summary of script use.
 * estimation_scalability.txt:  the summary of performance experiments for detector/monitor rate estimation.